﻿
$IsModified = (Get-ItemProperty -Path HKLM:\SOFTWARE\TSLaunch -Name IsModified -EA SilentlyContinue).IsModified -eq "True"

if($IsModified) {
    $UPGLanguage = (Get-ItemProperty -Path HKLM:\SOFTWARE\TSLaunch -Name UPGLanguage).UPGLanguage
    Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\Nls\Language -Name InstallLanguage -Value $UPGLanguage -Type String -Force
    Remove-Item -Path 'HKLM:\SOFTWARE\TSLaunch' -Recurse -Force -EA SilentlyContinue
}