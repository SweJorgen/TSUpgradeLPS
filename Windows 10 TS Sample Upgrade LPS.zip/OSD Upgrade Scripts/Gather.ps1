﻿<#
    Name: Gather.ps1
    Author: Johan Schrewelius, Onevinn AB
    Date: 2016-10-24
    Command: powershell.exe -executionpolicy bypass -file gather.ps1
    Usage: Run in SCCM Task Sequence as lightweight replacement for MDT Gather Step
    Remark: Creates and sets a limited number of MDT Task Sequence variables, the most commonly used - subjectiveley
#>


$DesktopChassisTypes = @("3","4","5","6","7","13","15","16")
$LatopChassisTypes = @("8","9","10","11","12","14","18","21")
$ServerChassisTypes = @("23")

$tsenv = New-Object -ComObject Microsoft.SMS.TSEnvironment

$TmpCmpName = $tsenv.Value("OSDComputerName")

if(!$TmpCmpName) {
    $tsenv.Value("OSDComputerName") = $tsenv.Value("_SMSTSMachineName")
}

$cmp = gwmi -Class 'Win32_ComputerSystemProduct'
$tsenv.Value("OSDComputerUUID") = $cmp.UUID
$tsenv.Value("Model") = $cmp.Name
$tsenv.Value("Vendor") = $cmp.Vendor

$bios = gwmi -Class 'Win32_BIOS'
$tsenv.Value("SerialNumber") = $bios.SerialNumber
$tsenv.Value("BIOSVersion") = $bios.SMBIOSBIOSVersion

$chassi = gwmi -Class 'Win32_SystemEnclosure' 
$tsenv.Value("AssetTag") = $chassi.SMBIOSAssetTag

$chassi.ChassisTypes | foreach {
    $tsenv.Value("IsDesktop") = [string]$DesktopChassisTypes.Contains($_.ToString())
    $tsenv.Value("IsLaptop") = [string]$LatopChassisTypes.Contains($_.ToString())
    $tsenv.Value("IsServer") = [string]$ServerChassisTypes.Contains($_.ToString())
}

(gwmi -Class 'Win32_NetworkAdapterConfiguration' -Filter "IPEnabled = 1").IPAddress | foreach {
    if($_.IndexOf('.') -gt 0) {
        $tsenv.Value("IPAddress") = $_
    }
}

$tsenv.Value("OSDComputerMAC") = (gwmi -Class 'Win32_NetworkAdapter' -Filter "NetConnectionStatus = 2").MACAddress