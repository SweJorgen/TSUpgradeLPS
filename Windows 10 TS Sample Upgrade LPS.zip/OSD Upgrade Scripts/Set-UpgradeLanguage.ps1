﻿
$UPGLanguage = (Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\Nls\Language -Name InstallLanguage).InstallLanguage
$IsModified = (Get-ItemProperty -Path HKLM:\SOFTWARE\TSLaunch -Name IsModified -EA SilentlyContinue).IsModified -eq "True"

if(($UPGLanguage -ne "0409") -and !$IsModified) {
    Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\Nls\Language -Name InstallLanguage -Value 0409 -Type String -Force

    New-Item -Path HKLM:\SOFTWARE -Name TSLaunch -Force
    Set-ItemProperty -Path HKLM:\SOFTWARE\TSLaunch -Name IsModified -Value "True" -Type String -Force
    Set-ItemProperty -Path HKLM:\SOFTWARE\TSLaunch -Name UPGLanguage -Value "$UPGLanguage" -Type String -Force
}
